# CartaTAD
ADA Final Practice

Pendiente:

- Implementar métodos própios de la carta.adb
- Implementar métodos para insertar y leer los comentarios desde el trie
- Implementar inicialización del main 'Restaurant'